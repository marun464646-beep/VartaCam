# Keep CameraX and related classes
-keep class androidx.camera.** { *; }
