package com.vartacam.app.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.location.Location
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.min

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var coordinatesText by remember { mutableStateOf<String?>(null) }
    var latestLocation by remember { mutableStateOf<Location?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }

    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    val previewView = remember { PreviewView(context) }

    // Получаем координаты один раз при старте
    LaunchedEffect(Unit) {
        val fused = LocationServices.getFusedLocationProviderClient(context)
        try {
            fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
                .addOnSuccessListener { loc ->
                    if (loc != null) {
                        latestLocation = loc
                        coordinatesText = String.format(
                            Locale.US,
                            "%.6f  %.6f",
                            loc.latitude,
                            loc.longitude
                        )
                    }
                }
        } catch (_: SecurityException) { }
    }

    // Привязка камеры при смене объектива
    LaunchedEffect(lensFacing) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            imageCapture = capture

            val selector = CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build()

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    capture
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    DisposableEffect(Unit) {
        onDispose { cameraExecutor.shutdown() }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Превью
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )

        // Крестик
        CrosshairOverlay()

        // Координаты
        coordinatesText?.let { coords ->
            Text(
                text = coords,
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 48.dp)
                    .background(
                        Color.Black.copy(alpha = 0.55f),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            )
        }

        // Нижняя панель
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 42.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Переключение камеры
            IconButton(
                onClick = {
                    lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                        CameraSelector.LENS_FACING_FRONT
                    else
                        CameraSelector.LENS_FACING_BACK
                },
                modifier = Modifier
                    .size(56.dp)
                    .background(Color.White.copy(alpha = 0.22f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Cameraswitch,
                    contentDescription = "Сменить камеру",
                    tint = Color.White
                )
            }

            // Кнопка съёмки
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .background(Color.White.copy(alpha = 0.35f), CircleShape)
                    .padding(5.dp)
                    .background(Color.White, CircleShape)
                    .clickable {
                        takePhoto(
                            context = context,
                            imageCapture = imageCapture,
                            location = latestLocation,
                            executor = cameraExecutor
                        )
                    }
            )

            // Галерея (инфо)
            IconButton(
                onClick = {
                    Toast.makeText(
                        context,
                        "Фото сохраняются в Галерею → папка VartaCam",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                modifier = Modifier
                    .size(56.dp)
                    .background(Color.White.copy(alpha = 0.22f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Photo,
                    contentDescription = "Галерея",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
fun CrosshairOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val arm = min(size.width, size.height) / 17f
        val gap = 11f
        val stroke = 3.8f
        val color = Color.Red.copy(alpha = 0.92f)

        // Вертикаль
        drawLine(color, Offset(cx, cy - arm - gap), Offset(cx, cy - gap), stroke)
        drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + arm + gap), stroke)
        // Горизонталь
        drawLine(color, Offset(cx - arm - gap, cy), Offset(cx - gap, cy), stroke)
        drawLine(color, Offset(cx + gap, cy), Offset(cx + arm + gap, cy), stroke)
        // Точка
        drawCircle(color, radius = 4.5f, center = Offset(cx, cy))
    }
}

private fun takePhoto(
    context: Context,
    imageCapture: ImageCapture?,
    location: Location?,
    executor: ExecutorService
) {
    val capture = imageCapture ?: return

    val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
        .format(System.currentTimeMillis())

    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "VartaCam_$name")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VartaCam")
        }
    }

    val outputOptions = ImageCapture.OutputFileOptions.Builder(
        context.contentResolver,
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        contentValues
    ).build()

    capture.takePicture(
        outputOptions,
        executor,
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                // После сохранения впекаем крестик и координаты
                val uri = output.savedUri ?: return
                try {
                    // Читаем сохранённый файл
                    val inputStream = context.contentResolver.openInputStream(uri) ?: return
                    val original = BitmapFactory.decodeStream(inputStream)
                    inputStream.close()

                    if (original == null) return

                    // Рисуем крестик + текст координат
                    val stamped = stampCrosshairAndCoords(original, location)

                    // Перезаписываем
                    context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                        stamped.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    }

                    // Пишем EXIF с GPS (на случай если система не записала)
                    if (location != null) {
                        try {
                            context.contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                                val exif = ExifInterface(pfd.fileDescriptor)
                                exif.setLatLong(location.latitude, location.longitude)
                                exif.setAttribute(
                                    ExifInterface.TAG_DATETIME_ORIGINAL,
                                    SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
                                        .format(Date())
                                )
                                exif.saveAttributes()
                            }
                        } catch (_: Exception) { }
                    }

                    original.recycle()
                    stamped.recycle()

                    // Уведомление в UI-потоке
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        Toast.makeText(context, "Сохранено с крестиком", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        Toast.makeText(context, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(context, "Ошибка съёмки: ${exception.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    )
}

/**
 * Рисует крестик точно по центру кадра и координаты внизу.
 */
private fun stampCrosshairAndCoords(source: Bitmap, location: Location?): Bitmap {
    val result = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(result)

    val w = result.width.toFloat()
    val h = result.height.toFloat()
    val cx = w / 2f
    val cy = h / 2f

    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED.toArgb()
        strokeWidth = maxOf(3f, w / 400f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    val arm = w / 22f
    val gap = w / 80f

    // Крестик
    canvas.drawLine(cx, cy - arm - gap, cx, cy - gap, paint)
    canvas.drawLine(cx, cy + gap, cx, cy + arm + gap, paint)
    canvas.drawLine(cx - arm - gap, cy, cx - gap, cy, paint)
    canvas.drawLine(cx + gap, cy, cx + arm + gap, cy, paint)

    // Центральная точка
    paint.style = Paint.Style.FILL
    canvas.drawCircle(cx, cy, maxOf(4f, w / 250f), paint)

    // Координаты внизу
    if (location != null) {
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = maxOf(28f, w / 28f)
            setShadowLayer(4f, 1f, 1f, android.graphics.Color.BLACK)
            typeface = Typeface.MONOSPACE
        }
        val text = String.format(
            Locale.US,
            "%.6f  %.6f",
            location.latitude,
            location.longitude
        )
        val textWidth = textPaint.measureText(text)
        val x = (w - textWidth) / 2f
        val y = h - maxOf(40f, h / 25f)
        canvas.drawText(text, x, y, textPaint)
    }

    return result
}

// Расширение для Color → ARGB
private fun Color.toArgb(): Int {
    return android.graphics.Color.argb(
        (alpha * 255).toInt(),
        (red * 255).toInt(),
        (green * 255).toInt(),
        (blue * 255).toInt()
    )
}
